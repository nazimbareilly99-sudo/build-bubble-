# Bubble Blast — Android APK Build Guide

This package contains a complete, ready-to-compile Android project configured for **Bubble Blast** (`com.bubbleblast.arcade`, v1.0.0).

## Method 1: Build APK in the Cloud with GitHub Actions (No Install Required)
1. Create a new GitHub repository and upload the contents of this ZIP file.
2. Open the **Actions** tab in your GitHub repository.
3. The included workflow (`.github/workflows/build-apk.yml`) will automatically compile the Android app and publish **BubbleBlast-APK** as a downloadable `.apk` file!

## Method 2: Build with Android Studio
1. Open **Android Studio** and select **Open**.
2. Choose this extracted project folder.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your installable APK will be generated in `app/build/outputs/apk/debug/app-debug.apk`.

## Method 3: Instant Cloud APK via PWABuilder
1. Open [https://www.pwabuilder.com](https://www.pwabuilder.com)
2. Paste your live Bubble Blast URL: `https://ais-dev-myfzamlxsuael6v6yix45n-791850723208.asia-northeast1.run.app`
3. Click **Package for Stores > Android > Download Package** to get a signed APK and Google Play AAB bundle immediately.
