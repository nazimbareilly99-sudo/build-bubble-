#!/usr/bin/env bash
set -e
echo "Building Bubble Blast Android APK..."
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug
else
  ./gradlew assembleDebug
fi
echo "APK built successfully at: app/build/outputs/apk/debug/app-debug.apk"
